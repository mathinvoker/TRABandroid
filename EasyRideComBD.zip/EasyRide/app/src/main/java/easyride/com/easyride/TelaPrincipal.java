package easyride.com.easyride;

import android.content.Intent;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;


public class TelaPrincipal extends ActionBarActivity {

    private int idUsuario = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_principal);

        Intent it = getIntent();
        idUsuario = it.getIntExtra("idUsuario",0);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_tela_principal, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }


    public void cadastrarCarona(View v) {

        Intent it = new Intent(this, CadastroCarona.class);
        it.putExtra("idUsuario", idUsuario);
        startActivity(it);
    }

    public void avaliarCarona(View v) {

        Intent it = new Intent(this, AvaliarCarona.class);
        it.putExtra("idUsuario", idUsuario);
        startActivity(it);
    }

    public void buscarCarona(View v) {

        Intent it = new Intent(this, BuscarCarona.class);
        it.putExtra("idUsuario", idUsuario);
        startActivity(it);
    }
}
