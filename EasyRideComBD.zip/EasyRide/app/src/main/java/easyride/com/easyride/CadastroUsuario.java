package easyride.com.easyride;

import android.content.ContentValues;
import android.content.Intent;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import easyride.com.easyride.BancoDados.Database;
import easyride.com.easyride.Model.Usuario;


public class CadastroUsuario extends ActionBarActivity {

    public static Database bd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro_usuario);

        bd = new Database(this);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_cadastro_usuario, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    /*
    public boolean EmailValido(String email) {

        return email.contains("@");
    }

    public boolean SenhaValida(String password) {

        return password.length() > 8;
    }
*/
    public void cadastraUsuario (View v){
        DbHelper Helper = new DbHelper(this);

        EditText email = (EditText) findViewById(R.id.email);
        EditText password = (EditText) findViewById(R.id.password);
        EditText whatsapp = (EditText) findViewById(R.id.whatsapp);
        EditText idade = (EditText)findViewById(R.id.age);
        EditText nome = (EditText)findViewById(R.id.nome);

        //Usuario user = new Usuario(email.getText().toString(), password.getText().toString(), whatsapp.getText().toString());

        ContentValues values = new ContentValues();
        values.put("email", email.getText().toString());
        values.put("senha", password.getText().toString());
        values.put("numWhatsApp", whatsapp.getText().toString());
        values.put("idade", idade.getText().toString());
        values.put("nome", nome.getText().toString());

        // INSERE O USUARIO NO BANCO DE DADOS
        bd.inserir("Usuario", values);

        // MSG DE CONFIRMACAO DA INSERCAO
        Toast.makeText(this, "Usuário cadastrado com sucesso!", Toast.LENGTH_SHORT).show();

        //Helper.insertUsuario(user);
        //Global.usuarios.add(user);
        Intent i = new Intent(this, LoginUsuario.class);
        startActivity(i);
    }
}
