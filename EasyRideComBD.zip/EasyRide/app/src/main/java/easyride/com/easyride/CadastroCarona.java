package easyride.com.easyride;

import android.content.ContentValues;
import android.content.Intent;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import easyride.com.easyride.BancoDados.Database;
import easyride.com.easyride.Model.Carona;

public class CadastroCarona extends ActionBarActivity {

    public static Database bd;
    private int idUsuario = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro_carona);

        Intent it = getIntent();
        idUsuario = it.getIntExtra("idUsuario",0);

        bd = new Database(this);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_cadastro_carona, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public void cadastraCarona(View v){

        EditText departureCity = (EditText) findViewById(R.id.departureCity);
        EditText departureAddress = (EditText) findViewById(R.id.departureAddress);
        EditText destinationCity = (EditText) findViewById(R.id.destinationCity);
        EditText destinationAddress = (EditText) findViewById(R.id.destinationAddress);
        EditText date = (EditText) findViewById(R.id.date);
        EditText time = (EditText) findViewById(R.id.time);
        EditText seatsAvailable = (EditText) findViewById(R.id.seatsAvailable);

        /*Carona carona = new Carona(departureCity.getText().toString(), departureAddress.getText().toString(),
                destinationCity.getText().toString(), destinationAddress.getText().toString(),
                date.getText().toString(), time.getText().toString(), seatsAvailable.getText().toString());
        */

        ContentValues values = new ContentValues();
        values.put("idUsuario", idUsuario);
        values.put("cidadeDes", destinationCity.getText().toString());
        values.put("cidadeOri", departureCity.getText().toString());
        values.put("dataSaida", date.getText().toString());
        values.put("horarioSaida", time.getText().toString());
        values.put("quantVagas", seatsAvailable.getText().toString());
        values.put("localSaida", departureAddress.getText().toString());

        // INSERE A CARONA NO BANCO DE DADOS
        bd.inserir("Carona", values);

        // MSG DE CONFIRMACAO DA INSERCAO
        Toast.makeText(this, "Carona cadastrada com sucesso!", Toast.LENGTH_SHORT).show();

        Intent it = new Intent(this, TelaPrincipal.class);
        startActivity(it);
    }
}
