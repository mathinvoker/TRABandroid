package easyride.com.easyride;

import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;

import easyride.com.easyride.BancoDados.Database;
import easyride.com.easyride.Model.Carona;


public class BuscarCarona extends ActionBarActivity {

    public static Database bd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_buscar_carona);

        bd = new Database(this);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_buscar_carona, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public void buscarCarona(View v){

        EditText origin = (EditText) findViewById(R.id.departureCity);
        EditText destiny = (EditText) findViewById(R.id.departureAddress);
        EditText date = (EditText) findViewById(R.id.date);
        EditText time = (EditText) findViewById(R.id.destinationAddress);

        /*Carona carona = new Carona(origin.getText().toString(), destiny.getText().toString(),
                date.getText().toString(), time.getText().toString());*/

        ArrayList<String> whereList = new ArrayList<String>();
        if(origin.getText()!=null && (!origin.getText().toString().equals("")))
            whereList.add("cidadeOri = '"+origin.getText().toString()+"'");
        if(destiny.getText()!=null && (!destiny.getText().toString().equals("")))
            whereList.add("cidadeDes = '"+destiny.getText().toString()+"'");
        if(date.getText()!=null && (!date.getText().toString().equals("")))
            whereList.add("dataSaida = '"+date.getText().toString()+"'");
        if(time.getText()!=null && (!time.getText().toString().equals("")))
            whereList.add("horarioSaida = '"+time.getText().toString()+"'");

        String where = "";
        for(String w : whereList){
            // se for o ultimo elemento
            if(w.equals(whereList.get(whereList.size()-1)))
                where += w;
            else
                where += w + " AND ";
        }

        // PESQUISA NO BANCO
        Cursor c = bd.buscar("Carona", new String[]{"idCarona, idUsuario, cidadeDes, cidadeOri, dataSaida, horarioSaida," +
                "quantVagas, localSaida"}, where, "horarioSaida asc");

        Intent it = new Intent(this, ListarCaronas.class);
        ArrayList<Carona> caronas = new ArrayList();
        //ArrayList caronasId = new ArrayList();

        if(c.getCount() > 0) {
            while(c.moveToNext()) {
                int idU = c.getColumnIndex("idUsuario");
                int idC = c.getColumnIndex("idCarona");
                int cidO = c.getColumnIndex("cidadeOri");
                int loc = c.getColumnIndex("localSaida");
                int cidD = c.getColumnIndex("cidadeDes");
                int dat = c.getColumnIndex("dataSaida");
                int hor = c.getColumnIndex("horarioSaida");
                int qtd = c.getColumnIndex("quantVagas");

                Carona carona = new Carona(c.getInt(idU),c.getInt(idC), c.getString(cidO),c.getString(loc),
                        c.getString(cidD), c.getString(dat),c.getString(hor),c.getString(qtd));
                caronas.add(carona);
                //caronasId.add(c.getInt(idC));
            }
            c.close();
            startActivity(it);
        }
        else{
            Toast.makeText(this, "Nenhuma carona encontrada!", Toast.LENGTH_SHORT).show();
            c.close();
        }

        // ENVIA RESULTADO PARA A PROXIMA TELA
        /*for(Carona carona : caronas){
            it.putExtra(Integer.toString(carona.getIdCarona()), carona);
        }*/
        //it.putExtra("caronasId", caronasId);
        it.putExtra("caronas", caronas);
        startActivity(it);
    }
}
