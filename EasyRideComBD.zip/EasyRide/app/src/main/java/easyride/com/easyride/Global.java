


package easyride.com.easyride;

import easyride.com.easyride.Model.Usuario;

import java.util.ArrayList;

public class Global {
    public static ArrayList <Usuario> usuarios = new ArrayList<Usuario>();
}
