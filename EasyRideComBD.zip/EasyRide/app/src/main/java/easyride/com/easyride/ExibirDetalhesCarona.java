package easyride.com.easyride;

import android.content.Intent;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import easyride.com.easyride.Model.Carona;


public class ExibirDetalhesCarona extends ActionBarActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exibir_detalhes_carona);

        Intent it = getIntent();
        Carona carona = (Carona)it.getSerializableExtra("carona");
        preencheTela(carona);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_exibir_detalhes_carona, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public void Voltar(View v){

        finish();
    }

    private void preencheTela(Carona carona){

        TextView departureCity = (TextView) findViewById(R.id.departureCity);
        TextView departureAddress = (TextView) findViewById(R.id.departureAddress);
        TextView destinationCity = (TextView) findViewById(R.id.destinationCity);
        TextView date = (TextView) findViewById(R.id.date);
        TextView time = (TextView) findViewById(R.id.time);
        TextView seatsAvailable = (TextView) findViewById(R.id.seatsAvailable);

        departureCity.setText(carona.getDepartureCity());
        departureAddress.setText(carona.getDepartureAddress());
        destinationCity.setText(carona.getDestinationCity());
        date.setText(carona.getDepartureDate());
        time.setText(carona.getDepartureTime());
        seatsAvailable.setText(carona.getSeatsAvailable());
    }
}
