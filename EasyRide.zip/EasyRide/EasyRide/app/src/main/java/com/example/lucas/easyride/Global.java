


package com.example.lucas.easyride;

import com.example.lucas.easyride.Model.Usuario;

import java.util.ArrayList;

public class Global {
    public static ArrayList <Usuario> usuarios = new ArrayList<Usuario>();
}
